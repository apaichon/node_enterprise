const DB_SERVER = {
  dev: {
    host: 'localhost',
    port: 27017,
    url: 'mongodb://localhost:27017/membership'
  } 
}

export {
  DB_SERVER
}