const MEMBERS = {
  ADD_URL: '/membership/Members/Add',
  EDIT_URL: '/membership/Members/Edit',
  DELETE_URL: '/membership/Members/Delete',
  GET_URL: '/membership/Members/Get'
}

export {
  MEMBERS
}