function f (x, y = 7, z = 42) { return x + y + z }

export default f