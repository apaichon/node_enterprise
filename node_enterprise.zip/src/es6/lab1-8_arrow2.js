let nums = [1, 2, 3, 4, 5], fives = []
nums.forEach(v => { if (v % 5 === 0) fives.push(v) })

export default nums
