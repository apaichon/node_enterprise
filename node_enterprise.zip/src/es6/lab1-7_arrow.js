let evens = [2, 4, 6, 8]
let odds  = evens.map(v => v + 1)

export default odds
