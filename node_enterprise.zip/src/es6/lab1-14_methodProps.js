const obj = {
  foo (a, b) {
    return a + b 
  },
  bar (x, y) {
    return x * y
  }
}

export default obj