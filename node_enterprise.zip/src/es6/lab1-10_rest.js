function f (x, y, ...a) {
  return (x + y) * a.length
}

export default f