const bin = 0b111110111
const oct = 0o767

export {
  bin,
  oct
}