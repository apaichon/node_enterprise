export { pi } from "../lib/math"
export var e = 2.71828182846
export default (x) => Math.exp(x)
