const number = 99, text = 'Hello', object = {id: 1, name: 'John'}
export {
  number,
  text,
  object
}